package com.simats.tenderanalyser.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DarkBg = Color(0xFF121212)
private val Gold = Color(0xFFFFC107)
private val TextGray = Color(0xFFA0A0A0)
private val OutlineColor = Color(0xFF333333)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthorityTermsScreen(onBackClick: () -> Unit) {
    Scaffold(
        containerColor = DarkBg,
        topBar = {
            TopAppBar(
                title = { Text("TERMS OF USE", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Gold) } },
                actions = { IconButton(onClick = { }) { Icon(Icons.Default.Gavel, contentDescription = null, tint = Gold) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        bottomBar = {
            Surface(color = DarkBg) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("ID: AUTH-HUB-LEGAL-2023-V2", color = OutlineColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onBackClick, modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold)
                    ) {
                        Text("ACCEPT & CLOSE", color = Color.Black, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {

            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Column {
                    Text("STANDARD PROTOCOL", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Authority Hub", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("VERSION 2.4.0", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Last Rev: Oct 2023", color = TextGray, fontSize = 10.sp)
                }
            }
            Spacer(modifier = Modifier.height(32.dp))

            TermsSection("Administrative Verification", "Access to the Tendering Authority portal is strictly reserved for authenticated personnel. Mandatory multi-factor authentication (MFA) and background validation are prerequisites for system entry. Users are custodians of their administrative credentials.")
            TermsSection("Data Sovereignty", "All data hosted within this environment remains the exclusive property of the Tendering Authority. Unauthorized extraction, duplication, or dissemination of procurement sensitive information is strictly prohibited under the sovereign data protection acts.")
            TermsSection("Administrative Authorization", "Any action performed within the portal is logged with a permanent cryptographic timestamp. Users must ensure that all Notice Inviting Tenders (NIT) comply with the statutory standards of transparency and merit-based selection.")
            TermsSection("DSC Requirements", "Final approvals and high-value tender awards must be authorized using a Class III Digital Signature Certificate. The signatory assumes full legal liability for all digitally signed documents and communications.")
            TermsSection("Jurisdiction", "The use of this platform is governed by the laws of the national capital territory. Any disputes or discrepancies arising from portal usage shall be settled within the designated high courts of the primary jurisdiction.")

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TermsSection(title: String, body: String) {
    Column(modifier = Modifier.padding(bottom = 24.dp)) {
        Text(title, color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(body, color = TextGray, fontSize = 12.sp, lineHeight = 20.sp, textAlign = TextAlign.Justify)
    }
}