package com.simats.tenderanalyser.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DarkBg = Color(0xFF121212)
private val CardBg = Color(0xFF1A1A24)
private val Gold = Color(0xFFFFC107)
private val TextGray = Color(0xFFA0A0A0)
private val OutlineColor = Color(0xFF333333)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthorityAboutUsScreen(onBackClick: () -> Unit) {
    Scaffold(
        containerColor = DarkBg,
        topBar = {
            TopAppBar(
                title = { Text("About Us", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {

            Spacer(modifier = Modifier.height(16.dp))
            Text("OUR MISSION", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Revolutionizing Public Procurement through Intelligence", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Text("We empower tendering authorities with state-of-the-art AI tools to ensure every public project is managed with absolute integrity, unprecedented speed, and data-driven precision.", color = TextGray, fontSize = 13.sp, lineHeight = 22.sp)

            Spacer(modifier = Modifier.height(32.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                AboutFeatureItem(Modifier.weight(1f), Icons.Default.Visibility, "TRANSPARENCY", "End-to-end visibility\nin every bid")
                AboutFeatureItem(Modifier.weight(1f), Icons.Default.Speed, "EFFICIENCY", "Faster processing\ncycles")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = CardBg), border = BorderStroke(1.dp, OutlineColor)) {
                Column(modifier = Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.TrackChanges, contentDescription = null, tint = Gold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("AI-DRIVEN ANALYTICS", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Predictive insights for project success", color = TextGray, fontSize = 9.sp)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Stats Box
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = DarkBg), border = BorderStroke(1.dp, Gold)) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("12,480+", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Text("TOTAL PROJECTS MANAGED", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row {
                        Box(modifier = Modifier.size(32.dp).background(Color.Gray, CircleShape).border(2.dp, DarkBg, CircleShape))
                        Box(modifier = Modifier.size(32.dp).offset(x = (-10).dp).background(Color.LightGray, CircleShape).border(2.dp, DarkBg, CircleShape))
                        Box(modifier = Modifier.size(32.dp).offset(x = (-20).dp).background(Color(0xFF2A2A2A), CircleShape).border(2.dp, DarkBg, CircleShape), contentAlignment = Alignment.Center) {
                            Text("+4K", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Text("CONTACT OFFICE", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(20.dp))

            ContactRow(Icons.Outlined.LocationOn, "Headquarters", "Central Secretariat, North Block,\nNew Delhi, India 110001")
            Spacer(modifier = Modifier.height(20.dp))
            ContactRow(Icons.Outlined.Language, "Official Portal", "www.authority-portal.gov.in", isLink = true)
            Spacer(modifier = Modifier.height(20.dp))
            ContactRow(Icons.Outlined.Email, "Email Support", "contact@tenderintelligence.hub")

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun AboutFeatureItem(modifier: Modifier, icon: ImageVector, title: String, subtitle: String) {
    Card(modifier = modifier, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = CardBg), border = BorderStroke(1.dp, OutlineColor)) {
        Column(modifier = Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, color = TextGray, fontSize = 9.sp, textAlign = TextAlign.Center, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun ContactRow(icon: ImageVector, title: String, detail: String, isLink: Boolean = false) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(detail, color = if (isLink) Gold else TextGray, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}