package com.simats.tenderanalyser.bidderhome

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean)

class TenderAiViewModel : ViewModel() {

    // --- CLASS LEVEL PROPERTIES (private is allowed here) ---
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(ChatMessage("Welcome! What can I do for you?", isUser = false))
    )
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private var currentTenderInfo: String = "No specific tender selected yet. " +
            "Please act as a helpful assistant for the Tender Analyser app. " +
            "If the user says 'hi' or starts a conversation, respond with: " +
            "'Hello! How can I help you with your tenders today?'"

    private val generativeModel = GenerativeModel(
        modelName = "gemini-2.5-flash",
        apiKey = "AIzaSyAKJs0I4Nx7nZYZUO20obl-kt7nFIUA3jQ"
    )

    // --- FUNCTIONS (private is NOT allowed for variables inside here) ---
    fun setTenderContext(tenderId: String, details: String) {
        currentTenderInfo = "TENDER ID: $tenderId\nDETAILS: $details"
        _chatHistory.value = listOf(ChatMessage("Welcome! What can I do for you?", isUser = false))
    }

    fun askQuestion(userInput: String) {
        if (userInput.isBlank()) return

        viewModelScope.launch {
            // Local variables like 'currentList' cannot have 'private'
            val currentList = _chatHistory.value.toMutableList()
            currentList.add(ChatMessage(userInput, isUser = true))
            _chatHistory.value = currentList

            _isLoading.value = true
            try {
                val combinedPrompt = """
                    SYSTEM: You are a professional Tender Analyst. 
                    CONTEXT: $currentTenderInfo
                    
                    USER QUESTION: $userInput
                """.trimIndent()

                val response = generativeModel.generateContent(combinedPrompt)
                val aiText = response.text ?: "I'm sorry, I couldn't process that request."

                val updatedList = _chatHistory.value.toMutableList()
                updatedList.add(ChatMessage(aiText, isUser = false))
                _chatHistory.value = updatedList
            } catch (e: Exception) {
                val errorList = _chatHistory.value.toMutableList()
                errorList.add(ChatMessage("Sorry, I'm having trouble connecting right now.", isUser = false))
                _chatHistory.value = errorList
            } finally {
                _isLoading.value = false
            }
        }
    }
}