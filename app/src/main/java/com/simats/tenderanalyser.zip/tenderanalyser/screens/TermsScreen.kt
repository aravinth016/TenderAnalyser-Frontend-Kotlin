package com.simats.tenderanalyser.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TermsScreen(onBackClick: () -> Unit) {
    val scrollState = rememberScrollState()
    val primaryBlue = Color(0xFF1B49B5)
    val textGray = Color(0xFF475569)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Terms of Use", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp).background(Color.White)) {
                Button(
                    onClick = onBackClick,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = primaryBlue)
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        },
        containerColor = Color.White
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Text("Last Updated: October 24, 2023", fontSize = 12.sp, color = textGray)
            Divider(color = primaryBlue, thickness = 2.dp, modifier = Modifier.width(32.dp).padding(vertical = 8.dp))
            Spacer(modifier = Modifier.height(16.dp))

            // Section 1
            Text("1. Acceptance of Terms", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text("By accessing or using our corporate tender application, you agree to be bound by these Terms of Use and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site. These terms constitute a legally binding agreement between you and the Tender Management Authority.", fontSize = 12.sp, color = textGray, lineHeight = 18.sp)
            Spacer(modifier = Modifier.height(24.dp))

            // Section 2
            Text("2. User Eligibility (GSTIN required)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Access to the bidding platform is restricted to legally registered corporate entities. All users must provide a valid Goods and Services Tax Identification Number (GSTIN) during the registration process. Failure to provide verifiable credentials will result in immediate suspension of account privileges and disqualification from active tenders.", fontSize = 12.sp, color = textGray, lineHeight = 18.sp)
            Spacer(modifier = Modifier.height(24.dp))

            // Section 3
            Text("3. AI Analysis Disclaimer", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text("This application utilizes artificial intelligence (AI) to assist in the preliminary evaluation and summarization of tender documents. While we strive for accuracy, AI-generated insights are for informational purposes only. Users are responsible for verifying all tender specifications and legal requirements manually before submitting a formal bid.", fontSize = 12.sp, color = textGray, lineHeight = 18.sp)
            Spacer(modifier = Modifier.height(16.dp))

            // Notice Box
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF1E222D),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Info, contentDescription = "Notice", tint = primaryBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("NOTICE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("The platform holds no liability for discrepancies between AI summaries and original legal document text.", fontSize = 11.sp, color = Color.LightGray, lineHeight = 16.sp)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))

            // Section 4
            Text("4. Bidding Rules", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Participating in the tender process requires strict adherence to ethical bidding standards. Any form of collusion, price-fixing, or fraudulent representation will lead to permanent blacklisting.", fontSize = 12.sp, color = textGray, lineHeight = 18.sp)
            Spacer(modifier = Modifier.height(12.dp))

            val rules = listOf("All bids must be submitted before the specified deadline.", "Bids once submitted cannot be retracted without written permission.", "The selection committee's decision is final and binding.")
            rules.forEach { rule ->
                Row(modifier = Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = primaryBlue, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(rule, fontSize = 12.sp, color = textGray, lineHeight = 18.sp)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))

            // Section 5
            Text("5. Data Privacy", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Your corporate data is handled in accordance with our Privacy Policy. By using this platform, you consent to the processing of your data for the purposes of tender evaluation and audit compliance.", fontSize = 12.sp, color = textGray, lineHeight = 18.sp)

            Spacer(modifier = Modifier.height(80.dp)) // Space for bottom button
        }
    }
}