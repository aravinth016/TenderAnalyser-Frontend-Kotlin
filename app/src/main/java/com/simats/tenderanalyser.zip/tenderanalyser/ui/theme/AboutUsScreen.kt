package com.simats.tenderanalyser.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutUsScreen(onBackClick: () -> Unit) {
    val scrollState = rememberScrollState()
    val primaryBlue = Color(0xFF1B49B5)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About Tender Analyser", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color.White
    ) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().padding(paddingValues).verticalScroll(scrollState)) {

            // Hero Image Placeholder
            Box(
                modifier = Modifier.fillMaxWidth().height(200.dp).background(Color.DarkGray),
                contentAlignment = Alignment.BottomStart
            ) {
                // TODO: Replace with Image()
                Column(modifier = Modifier.padding(16.dp)) {
                    Surface(color = Color(0xFFFFC107), shape = RoundedCornerShape(4.dp)) {
                        Text("INNOVATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Next-Gen Bidding", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            // Mission Statement
            Column(modifier = Modifier.padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Divider(modifier = Modifier.width(20.dp), color = primaryBlue, thickness = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("OUR MISSION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = primaryBlue)
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.height(IntrinsicSize.Min)) {
                    Divider(modifier = Modifier.width(3.dp).fillMaxHeight(), color = Color(0xFFFFC107))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("\"Simplifying Indian government tenders with AI. We empower businesses to navigate complex bidding processes with confidence and precision through cutting-edge technology.\"", fontSize = 14.sp, color = Color(0xFF475569), lineHeight = 22.sp)
                }
            }

            // Features Placeholder
            Text("Key Features", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(140.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(Icons.Outlined.Psychology, contentDescription = null, tint = primaryBlue)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("AI Summarization", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("Instantly extract critical terms, deadlines, and eligibility.", fontSize = 12.sp, color = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Visionaries Placeholder
            Text("Our Visionaries", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceAround) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.size(80.dp).clip(CircleShape).background(Color.LightGray)) // Placeholder
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Vikram Mehta", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("CEO & Founder", fontSize = 12.sp, color = Color.Gray)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.size(80.dp).clip(CircleShape).background(Color.LightGray)) // Placeholder
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ananya Iyer", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("CTO & Co-Founder", fontSize = 12.sp, color = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Footer
            Column(modifier = Modifier.fillMaxWidth().background(primaryBlue).padding(24.dp)) {
                Text("Get in Touch", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(24.dp))

                ContactRow(Icons.Outlined.LocationOn, "Corporate Office", "Tech Hub South, Bengaluru, 560001")
                Spacer(modifier = Modifier.height(16.dp))
                ContactRow(Icons.Outlined.Language, "Website", "www.tenderanalyser.ai")
                Spacer(modifier = Modifier.height(16.dp))
                ContactRow(Icons.Outlined.Email, "Email", "support@tenderanalyser.ai")

                Spacer(modifier = Modifier.height(32.dp))
                Divider(color = Color(0xFF3B82F6).copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(16.dp))
                Text("© 2024 TENDER ANALYSER PVT LTD.", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f), modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        }
    }
}

@Composable
fun ContactRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
    Row {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(value, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
        }
    }
}